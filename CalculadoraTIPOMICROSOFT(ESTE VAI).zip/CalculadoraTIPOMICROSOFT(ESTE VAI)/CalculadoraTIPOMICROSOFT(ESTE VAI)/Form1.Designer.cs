﻿namespace CalculadoraTIPOMICROSOFT_ESTE_VAI_
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtResultado = new System.Windows.Forms.TextBox();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.Btn1 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.BtnZero = new System.Windows.Forms.Button();
            this.Btnvirgula = new System.Windows.Forms.Button();
            this.BtnIgual = new System.Windows.Forms.Button();
            this.BtnAdição = new System.Windows.Forms.Button();
            this.BtnSubtração = new System.Windows.Forms.Button();
            this.BtnMultiplicação = new System.Windows.Forms.Button();
            this.BtnDivisão = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblOperação = new System.Windows.Forms.Label();
            this.MRCalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtResultado
            // 
            this.TxtResultado.Location = new System.Drawing.Point(12, 106);
            this.TxtResultado.Name = "TxtResultado";
            this.TxtResultado.ReadOnly = true;
            this.TxtResultado.Size = new System.Drawing.Size(318, 20);
            this.TxtResultado.TabIndex = 0;
            this.TxtResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtResultado.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(12, 190);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(75, 36);
            this.btn7.TabIndex = 1;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(93, 190);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(75, 36);
            this.btn8.TabIndex = 2;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(174, 190);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(75, 36);
            this.btn9.TabIndex = 3;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(174, 232);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(75, 36);
            this.btn6.TabIndex = 4;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(93, 232);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(75, 36);
            this.btn5.TabIndex = 5;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(12, 232);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(75, 36);
            this.btn4.TabIndex = 6;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // Btn1
            // 
            this.Btn1.Location = new System.Drawing.Point(12, 274);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(75, 36);
            this.Btn1.TabIndex = 7;
            this.Btn1.Text = "1";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // Btn2
            // 
            this.Btn2.Location = new System.Drawing.Point(93, 274);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(75, 36);
            this.Btn2.TabIndex = 8;
            this.Btn2.Text = "2";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // Btn3
            // 
            this.Btn3.Location = new System.Drawing.Point(174, 274);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(75, 36);
            this.Btn3.TabIndex = 9;
            this.Btn3.Text = "3";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // BtnZero
            // 
            this.BtnZero.Location = new System.Drawing.Point(93, 316);
            this.BtnZero.Name = "BtnZero";
            this.BtnZero.Size = new System.Drawing.Size(75, 36);
            this.BtnZero.TabIndex = 11;
            this.BtnZero.Text = "0";
            this.BtnZero.UseVisualStyleBackColor = true;
            this.BtnZero.Click += new System.EventHandler(this.BtnZero_Click);
            // 
            // Btnvirgula
            // 
            this.Btnvirgula.Location = new System.Drawing.Point(12, 316);
            this.Btnvirgula.Name = "Btnvirgula";
            this.Btnvirgula.Size = new System.Drawing.Size(75, 36);
            this.Btnvirgula.TabIndex = 12;
            this.Btnvirgula.Text = ",";
            this.Btnvirgula.UseVisualStyleBackColor = true;
            this.Btnvirgula.Click += new System.EventHandler(this.Btnvirgula_Click);
            // 
            // BtnIgual
            // 
            this.BtnIgual.BackColor = System.Drawing.SystemColors.HotTrack;
            this.BtnIgual.Location = new System.Drawing.Point(174, 316);
            this.BtnIgual.Name = "BtnIgual";
            this.BtnIgual.Size = new System.Drawing.Size(75, 36);
            this.BtnIgual.TabIndex = 13;
            this.BtnIgual.Text = "=";
            this.BtnIgual.UseVisualStyleBackColor = false;
            this.BtnIgual.Click += new System.EventHandler(this.BtnIgual_Click);
            // 
            // BtnAdição
            // 
            this.BtnAdição.Location = new System.Drawing.Point(255, 316);
            this.BtnAdição.Name = "BtnAdição";
            this.BtnAdição.Size = new System.Drawing.Size(75, 36);
            this.BtnAdição.TabIndex = 14;
            this.BtnAdição.Text = "+";
            this.BtnAdição.UseVisualStyleBackColor = true;
            this.BtnAdição.Click += new System.EventHandler(this.BtnAdição_Click);
            // 
            // BtnSubtração
            // 
            this.BtnSubtração.Location = new System.Drawing.Point(255, 274);
            this.BtnSubtração.Name = "BtnSubtração";
            this.BtnSubtração.Size = new System.Drawing.Size(75, 36);
            this.BtnSubtração.TabIndex = 15;
            this.BtnSubtração.Text = "-";
            this.BtnSubtração.UseVisualStyleBackColor = true;
            this.BtnSubtração.Click += new System.EventHandler(this.BtnSubtração_Click);
            // 
            // BtnMultiplicação
            // 
            this.BtnMultiplicação.Location = new System.Drawing.Point(255, 232);
            this.BtnMultiplicação.Name = "BtnMultiplicação";
            this.BtnMultiplicação.Size = new System.Drawing.Size(75, 36);
            this.BtnMultiplicação.TabIndex = 16;
            this.BtnMultiplicação.Text = "X";
            this.BtnMultiplicação.UseVisualStyleBackColor = true;
            this.BtnMultiplicação.Click += new System.EventHandler(this.BtnMultiplicação_Click);
            // 
            // BtnDivisão
            // 
            this.BtnDivisão.Location = new System.Drawing.Point(255, 190);
            this.BtnDivisão.Name = "BtnDivisão";
            this.BtnDivisão.Size = new System.Drawing.Size(75, 36);
            this.BtnDivisão.TabIndex = 17;
            this.BtnDivisão.Text = "/";
            this.BtnDivisão.UseVisualStyleBackColor = true;
            this.BtnDivisão.Click += new System.EventHandler(this.button17_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.DarkRed;
            this.btnLimpar.Location = new System.Drawing.Point(12, 148);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(318, 36);
            this.btnLimpar.TabIndex = 18;
            this.btnLimpar.Text = "C";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblOperação
            // 
            this.lblOperação.AutoSize = true;
            this.lblOperação.Location = new System.Drawing.Point(291, 106);
            this.lblOperação.Name = "lblOperação";
            this.lblOperação.Size = new System.Drawing.Size(0, 13);
            this.lblOperação.TabIndex = 19;
            // 
            // MRCalculate
            // 
            this.MRCalculate.CausesValidation = false;
            this.MRCalculate.Location = new System.Drawing.Point(12, 12);
            this.MRCalculate.Name = "MRCalculate";
            this.MRCalculate.Size = new System.Drawing.Size(332, 23);
            this.MRCalculate.TabIndex = 20;
            this.MRCalculate.Text = "MRCalculate";
            this.MRCalculate.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 358);
            this.Controls.Add(this.MRCalculate);
            this.Controls.Add(this.lblOperação);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.BtnDivisão);
            this.Controls.Add(this.BtnMultiplicação);
            this.Controls.Add(this.BtnSubtração);
            this.Controls.Add(this.BtnAdição);
            this.Controls.Add(this.BtnIgual);
            this.Controls.Add(this.Btnvirgula);
            this.Controls.Add(this.BtnZero);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn1);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.TxtResultado);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtResultado;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button BtnZero;
        private System.Windows.Forms.Button Btnvirgula;
        private System.Windows.Forms.Button BtnIgual;
        private System.Windows.Forms.Button BtnAdição;
        private System.Windows.Forms.Button BtnSubtração;
        private System.Windows.Forms.Button BtnMultiplicação;
        private System.Windows.Forms.Button BtnDivisão;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblOperação;
        private System.Windows.Forms.Button MRCalculate;
    }
}

