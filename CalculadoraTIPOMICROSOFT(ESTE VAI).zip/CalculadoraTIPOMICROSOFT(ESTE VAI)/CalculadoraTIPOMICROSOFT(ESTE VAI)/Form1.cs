﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Deployment.Application;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraTIPOMICROSOFT_ESTE_VAI_
{
    public partial class Form1 : Form
    {
        public decimal Resultado { get; set; }
        public decimal valor { get; set; }
        private operacao Operacaoselecionada { get; set; }

        enum operacao
        {
            adicao,
            subtração,
            Multiplicação,
            Divisão
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Operacaoselecionada = operacao.Divisão;
            valor = Convert.ToDecimal(TxtResultado.Text);
            TxtResultado.Text = "";
            lblOperação.Text = "/";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnZero_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "0";
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "1";
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "2";
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += "9";
        }

        private void BtnAdição_Click(object sender, EventArgs e)
        {
            Operacaoselecionada = operacao.adicao;
            valor = Convert.ToDecimal(TxtResultado.Text);
            TxtResultado.Text = "";
            lblOperação.Text = "+";


        }

        private void BtnSubtração_Click(object sender, EventArgs e)
        {
            Operacaoselecionada = operacao.subtração;
            valor = Convert.ToDecimal(TxtResultado.Text);
            TxtResultado.Text = "";
            lblOperação.Text = "-";

        }


        private void BtnMultiplicação_Click(object sender, EventArgs e)
        {
            Operacaoselecionada = operacao.Multiplicação;
            valor = Convert.ToDecimal(TxtResultado.Text);
            TxtResultado.Text = "";
            lblOperação.Text = "X";
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            TxtResultado.Text = "";
            lblOperação.Text = "";
        }

        private void BtnIgual_Click(object sender, EventArgs e)
        {
            switch (Operacaoselecionada)
            {
                case operacao.adicao:
                    Resultado = valor + Convert.ToDecimal(TxtResultado.Text);
                    break;
                case operacao.subtração:
                    Resultado = valor - Convert.ToDecimal(TxtResultado.Text);
                    break;
                case operacao.Multiplicação:
                    Resultado = valor * Convert.ToDecimal(TxtResultado.Text);
                    break;
                case operacao.Divisão:
                    Resultado = valor / Convert.ToDecimal(TxtResultado.Text);
                    break;



            }
            TxtResultado.Text = Convert.ToString(Resultado);
            lblOperação.Text = "=";
        }

        private void Btnvirgula_Click(object sender, EventArgs e)
        {
            TxtResultado.Text += ",";
        }
    }
}
